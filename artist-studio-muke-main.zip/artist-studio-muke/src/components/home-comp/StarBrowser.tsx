export default function StarBrowser(){
    return (
        <div>sss</div>
    )
}