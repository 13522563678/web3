import JordiEditor from  "./editor/JordiEditor"
export default JordiEditor